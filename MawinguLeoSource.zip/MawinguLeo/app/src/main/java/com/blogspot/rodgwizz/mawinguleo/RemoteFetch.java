package com.blogspot.rodgwizz.mawinguleo;

import android.os.AsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by RODGWIZZ on 9/24/2017.
 */

public class RemoteFetch extends AsyncTask<String,Void,String> {

        String result;
@Override
protected String doInBackground(String... urls) {
        result = "";
        URL link;
        HttpURLConnection myconnection = null;

        try {
        link = new URL(urls[0]);
        myconnection = (HttpURLConnection)link.openConnection();
        InputStream in = myconnection.getInputStream();
        InputStreamReader myStreamReader = new InputStreamReader(in);
        int data = myStreamReader.read();
        while(data!= -1){
        char current = (char)data;
        result+= current;
        data = myStreamReader.read();
        }
        return result;
        } catch (Exception e) {
        e.printStackTrace();
        }

        return null;
        }

@Override
protected void onPostExecute(String result) {
        super.onPostExecute(result);

        try {
        JSONObject jsonObject = new JSONObject(result);
        JSONObject weatherDatas = new JSONObject(jsonObject.getString("main"));
        double tempInt = Double.parseDouble(weatherDatas.getString("temp"));
        int tempIn = (int) (tempInt*1.8-459.67);
        String placeName = jsonObject.getString("name");

        Brave_Weather.temp.setText(String.valueOf(tempIn) + "Farenheight");

        Brave_Weather.place.setText(placeName);

        } catch (JSONException e) {
        e.printStackTrace();
        }
        }
        }
